/**
 * @file main.c
 * @brief Lab 2 - Single segment test for sign-off measurements.
 *
 * Turns ON segment a and leaves it on. With it running, measure:
 *   - Vf: across the lit segment (display anode pin to the resistor side
 *         of the segment pin, i.e. across the LED itself)
 *   - GPIO voltage: at GPIO19 (Pico pin 25) with respect to ground
 *
 * Common anode display: driving the pin LOW lights the segment.
 */

#include "pico/stdlib.h"

#define SEG_A_PIN 19   /* segment a -> R1 -> GPIO19 (Pico pin 25) */

int main() {
    gpio_init(SEG_A_PIN);
    gpio_set_dir(SEG_A_PIN, GPIO_OUT);
    gpio_put(SEG_A_PIN, 0);   /* 0 = segment a ON (sinks current) */

    while (true) {
        /* Nothing to do - segment stays lit for measurement */
    }
}
