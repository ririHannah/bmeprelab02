/**
 * @file main.c
 * @brief Lab 2 - Incrementing display: counts 0 to F on a 7-segment display.
 *
 * Hardware: 5161BS COMMON ANODE display. The anodes are tied to 3V3, each
 *           segment cathode goes through a 1K resistor to a GPIO pin.
 *           A segment LIGHTS when its GPIO is driven LOW (0).
 *
 * The digit changes once per second using a NON-BLOCKING software timer
 * (no sleep_ms), so the loop keeps running between updates.
 */

#include "pico/stdlib.h"

/* ---- GPIO pin assignments (verify against the Lab 2 schematic) ---- */
#define SEG_A_PIN 19
#define SEG_B_PIN 18
#define SEG_C_PIN 17
#define SEG_D_PIN 16
#define SEG_E_PIN 15
#define SEG_F_PIN 14
#define SEG_G_PIN 13

#define NUM_SEGMENTS 7       /* segments a-g (decimal point not used)     */
#define NUM_DIGITS   16      /* hex digits 0 through F                    */
#define UPDATE_MS    1000    /* time between digit changes in ms          */

/* Segment pins in order: bit 0 = a, bit 1 = b, ... bit 6 = g */
static const uint SEG_PINS[NUM_SEGMENTS] = {
    SEG_A_PIN, SEG_B_PIN, SEG_C_PIN, SEG_D_PIN,
    SEG_E_PIN, SEG_F_PIN, SEG_G_PIN
};

/* Digit patterns: bit set (1) = segment LIT. bit0=a ... bit6=g.
 * Inverted in show_pattern() because the display is active-low. */
static const uint8_t DIGIT_PATTERNS[NUM_DIGITS] = {
    0x3F, /* 0: a b c d e f   */
    0x06, /* 1: b c           */
    0x5B, /* 2: a b d e g     */
    0x4F, /* 3: a b c d g     */
    0x66, /* 4: b c f g       */
    0x6D, /* 5: a c d f g     */
    0x7D, /* 6: a c d e f g   */
    0x07, /* 7: a b c         */
    0x7F, /* 8: all segments  */
    0x6F, /* 9: a b c d f g   */
    0x77, /* A: a b c e f g   */
    0x7C, /* b: c d e f g     */
    0x39, /* C: a d e f       */
    0x5E, /* d: b c d e g     */
    0x79, /* E: a d e f g     */
    0x71  /* F: a e f g       */
};

/**
 * @brief Initialize all segment pins as outputs, all segments off.
 */
static void init_display(void) {
    for (int i = 0; i < NUM_SEGMENTS; i++) {
        gpio_init(SEG_PINS[i]);
        gpio_set_dir(SEG_PINS[i], GPIO_OUT);
        gpio_put(SEG_PINS[i], 1);   /* 1 = off for common anode */
    }
}

/**
 * @brief Light the segments in a pattern.
 * @param pattern Bit n set means segment n (a=0 ... g=6) should be lit.
 */
static void show_pattern(uint8_t pattern) {
    for (int i = 0; i < NUM_SEGMENTS; i++) {
        bool lit = (pattern >> i) & 1u;
        gpio_put(SEG_PINS[i], !lit);   /* active low: lit -> drive 0 */
    }
}

int main() {
    uint8_t  digit = 0;                                   /* current hex digit */
    uint32_t last_update_ms = to_ms_since_boot(get_absolute_time());

    init_display();
    show_pattern(DIGIT_PATTERNS[digit]);                  /* show the first digit */

    while (true) {
        uint32_t now_ms = to_ms_since_boot(get_absolute_time());

        /* Non-blocking timer: only act when UPDATE_MS has elapsed.
         * Unsigned subtraction stays correct even if the counter wraps. */
        if ((now_ms - last_update_ms) >= UPDATE_MS) {
            last_update_ms += UPDATE_MS;                  /* keep a steady 1 s rate */
            digit = (digit + 1) % NUM_DIGITS;             /* 0..F then wrap to 0 */
            show_pattern(DIGIT_PATTERNS[digit]);
        }

        /* Other work could go here - the loop is never blocked. */
    }
}
