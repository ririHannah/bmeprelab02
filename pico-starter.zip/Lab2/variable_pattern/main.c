/**
 * @file main.c
 * @brief Lab 2 - Variable update rate pattern on a 7-segment display.
 *
 * Lights pairs of segments in this repeating sequence:
 *   a+b, b+g, g+e, e+d, d+c, c+g, g+f
 * Each step starts at 2000 ms. After each full pass through the sequence the
 * step time is halved with a right shift (>> 1). When it reaches 0 it is
 * reset to 2000 ms.
 *
 * Hardware: 5161BS COMMON ANODE display - a segment lights when its GPIO is 0.
 * Timing uses a NON-BLOCKING software timer (no sleep_ms).
 */

#include "pico/stdlib.h"

/* ---- GPIO pin assignments (verify against the Lab 2 schematic) ---- */
#define SEG_A_PIN 19
#define SEG_B_PIN 18
#define SEG_C_PIN 17
#define SEG_D_PIN 16
#define SEG_E_PIN 15
#define SEG_F_PIN 14
#define SEG_G_PIN 13

#define NUM_SEGMENTS   7
#define NUM_STEPS      7
#define START_DELAY_MS 2000

/* Segment bit masks (1 = lit) */
#define SEG_A (1u << 0)
#define SEG_B (1u << 1)
#define SEG_C (1u << 2)
#define SEG_D (1u << 3)
#define SEG_E (1u << 4)
#define SEG_F (1u << 5)
#define SEG_G (1u << 6)

/* Segment pins in order: bit 0 = a ... bit 6 = g */
static const uint SEG_PINS[NUM_SEGMENTS] = {
    SEG_A_PIN, SEG_B_PIN, SEG_C_PIN, SEG_D_PIN,
    SEG_E_PIN, SEG_F_PIN, SEG_G_PIN
};

/* The 7 steps of the sequence */
static const uint8_t STEP_PATTERNS[NUM_STEPS] = {
    SEG_A | SEG_B,   /* Step 1 */
    SEG_B | SEG_G,   /* Step 2 */
    SEG_G | SEG_E,   /* Step 3 */
    SEG_E | SEG_D,   /* Step 4 */
    SEG_D | SEG_C,   /* Step 5 */
    SEG_C | SEG_G,   /* Step 6 */
    SEG_G | SEG_F    /* Step 7 */
};

/**
 * @brief Initialize all segment pins as outputs, all segments off.
 */
static void init_display(void) {
    for (int i = 0; i < NUM_SEGMENTS; i++) {
        gpio_init(SEG_PINS[i]);
        gpio_set_dir(SEG_PINS[i], GPIO_OUT);
        gpio_put(SEG_PINS[i], 1);   /* 1 = off for common anode */
    }
}

/**
 * @brief Light the segments in a pattern (bit n set = segment n lit).
 */
static void show_pattern(uint8_t pattern) {
    for (int i = 0; i < NUM_SEGMENTS; i++) {
        bool lit = (pattern >> i) & 1u;
        gpio_put(SEG_PINS[i], !lit);   /* active low */
    }
}

int main() {
    uint8_t  step = 0;                        /* index into STEP_PATTERNS */
    uint32_t delay_ms = START_DELAY_MS;       /* current time per step */
    uint32_t last_update_ms = to_ms_since_boot(get_absolute_time());

    init_display();
    show_pattern(STEP_PATTERNS[step]);        /* show step 1 immediately */

    while (true) {
        uint32_t now_ms = to_ms_since_boot(get_absolute_time());

        /* Non-blocking timer: advance only when delay_ms has elapsed */
        if ((now_ms - last_update_ms) >= delay_ms) {
            last_update_ms = now_ms;
            step++;

            if (step >= NUM_STEPS) {          /* sequence finished, repeat */
                step = 0;
                delay_ms = delay_ms >> 1;     /* halve with shift, not '/' */
                if (delay_ms == 0) {
                    delay_ms = START_DELAY_MS;
                }
            }
            show_pattern(STEP_PATTERNS[step]);
        }
    }
}
